const http = require('http');
const path = require('path');
const fs = require('fs');
// const express = require('express');
// const session = require('express-session');
// const bodyParser = require('body-parser');
// const mysql = require('mysql');

// var connection = mysql.createConnection({
//     host:'localhost', user:'root', password:'',database:'webtechlecture'
// });

// const app = express();
// app.use(express.static('public'));
// app.set('views', `${__dirname}/view`);
// app.set('view engine', 'pug');

// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(bodyParser.json());
// app.use(session({ secret: 'somesecretkey', resave: true, saveUninitialized: true }));

// app.listen(8001, 'localhost');


// app.get('/', (request, response) => {
//     var theuser = request.session.theuser;
//     response.render('index', { theuser: theuser });
// });


const server = http.createServer((req, res) => {    
    // if (req.url === '/') {
    //     fs.readFile(
    //         path.join(__dirname, 'public', 'index.html'), 
    //         (err, content) => {
    //             if (err) throw err;
    //         res.writeHead(200, { 'Content-Type': 'text/html'});
    //         res.end(content);
    //         }
    //     );
    // }

    // if (req.url === '/api/users') {
    //     const users = [
    //         { name: 'Bdada', age: 40},
    //         { name: 'dad', age:55}
    //     ];
    //     res.writeHead(200, { 'Content-Type': 'application/json'});
    //     res.end(JSON.stringify(users));

    // }


    let filePath = path.join(
        __dirname, 
        'public', 
        req.url === '/' ? 'index' : req.url

    );

    // Get extension
    let extname = path.extname(filePath);

    let contentType = 'text/html';

    switch(extname) {
        case '.js':
            contentType = 'text/javascript';
            break;
        
        case '.css':
            contentType = 'text/css';
            break;

        case '.json':
            contentType = 'application/json';
            break;

        case '.png':
            contentType = 'image/png';
            break;

        case '.jpg':
            contentType = 'image/jpq';
            break;
    }


    //read file
    fs.readFile(filePath, (err, content) => {
        if(err) {
            if(err.code == 'ENOENT') {
                // E404
                fs.readFile(path.join(__dirname, 'public', 'error.html'), (err, content) => {
                    res.writeHead(200, {'Content-Type': 'text/html'});
                    res.end(content, 'utf8');
                })
            } else {
                res.writeHead(500);
                res.end(`Server Error: ${err.code}`);
            }
        } else {
            res.writeHead(200, { 'Content-Type': contentType});
            res.end(content, 'utf8');
        }
    });

    // console.log(filePath);
    // res.end();

}); 

const PORT = process.env.PORT || 5000;

server.listen(PORT, () => console.log (`Server running on port ${PORT}`));

