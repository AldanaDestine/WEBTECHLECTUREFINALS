var mysql = require('mysql');
var express = require('express');
var app = express();

app.get('/', function(request , response) {
    fetchData(response);
    console.log('Done. Displayed Data!!');
});

var db =  mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'webtechlecture'
});

db.connect(function(err){
    if(err){
        throw err;
    }
    console.log("Connecting to the Database");
});

function executeQuery(sql , cb) {
    db.query(sql, function(error, result, fields) {
        if(error) {throw error;}
        cb(result);
    })
}

function fetchData(response){
    executeQuery("Select id, unit, request, status, schedule from request order by created_at", function(result){
        console.log(result);
        response.write('<table><tr>');
        for(var column in result[0]) {
            response.write('<td><label>' + column + '</label></td>');
            
        }response.write('</tr>');
        for(var row in result){
            response.write('<tr>');
            for (var column in result[row]){
                response.write('<td><label>' +result[row][column] + '</label></td>');
            }
            response.write('</tr>');
        }
        response.write('/table');
    });
}

app.listen(8080, function(){
    console.log('Listen to Port 8080');
})

const PORT = process.env.PORT || 5000;